#!/bin/bash
echo "Compiling Metro Map Planner..."
# No compilation needed for Python
echo "Done."