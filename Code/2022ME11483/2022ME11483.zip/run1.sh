#!/bin/bash
python3 metro_map_planner.py $1